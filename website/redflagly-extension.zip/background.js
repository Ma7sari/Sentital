chrome.runtime.onInstalled.addListener(() => {
  console.log("Smart Web Assistant installerad");
});
